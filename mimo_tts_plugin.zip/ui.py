import os
import time
import shutil

from qt.core import (QDialog, QVBoxLayout, QHBoxLayout, QPushButton,
                     QProgressBar, QTreeWidget, QTreeWidgetItem, QTabWidget,
                     QWidget, QLabel, QLineEdit, QComboBox, QTextEdit,
                     QGroupBox, QFileDialog, QMessageBox, QThread, QUrl,
                     QDesktopServices, Qt, pyqtSignal)
from calibre_plugins.mimo_tts_plugin.config import prefs
from calibre_plugins.mimo_tts_plugin.core.mimo_api import MiMoTTSClient
from calibre_plugins.mimo_tts_plugin.core.book_parser import BookParser

PRESET_VOICES = [
    'mimo_default (默认)',
    '冰糖',
    '茉莉',
    '苏打',
    '白桦',
    'Mia',
    'Chloe',
    'Milo',
    'Dean',
]

TREE_ROLE_TYPE = Qt.ItemDataRole.UserRole
TYPE_BOOK = 'book'
TYPE_CHAPTER = 'chapter'
TYPE_CHUNK = 'chunk'


class PreviewCloneWorker(QThread):
    """后台试听合成线程，避免阻塞 UI。"""
    finished_signal = pyqtSignal(bool, str)

    def __init__(self, api_key, audio_path, preview_text, output_dir, clone_prompt=''):
        super(PreviewCloneWorker, self).__init__()
        self.api_key = api_key
        self.audio_path = audio_path
        self.preview_text = preview_text
        self.output_dir = output_dir
        self.clone_prompt = clone_prompt

    def run(self):
        try:
            client = MiMoTTSClient(self.api_key)
            os.makedirs(self.output_dir, exist_ok=True)
            ts = time.strftime('%Y%m%d_%H%M%S')
            preview_file = os.path.join(self.output_dir, f'preview_{ts}.mp3')
            client.synthesize_clone(
                self.preview_text, preview_file, self.audio_path,
                self.clone_prompt)
            self.finished_signal.emit(True, preview_file)
        except Exception as e:
            self.finished_signal.emit(False, str(e))


class MiMoTTSDialog(QDialog):
    def __init__(self, gui, icon, do_user_config, db, book_ids):
        super(MiMoTTSDialog, self).__init__(gui)
        self.gui = gui
        self.do_user_config = do_user_config
        self.db = db
        self.book_ids = book_ids
        self.worker = None
        self.preview_worker = None
        self.chapters_data = None
        self._updating_checkboxes = False

        self.setWindowTitle('MiMo TTS - 电子书转有声书')
        self.setWindowIcon(icon)
        self.resize(900, 650)

        self.init_ui()
        self.load_book_data()

    # ── UI construction ──────────────────────────────────────────

    def init_ui(self):
        main_layout = QVBoxLayout(self)

        top_layout = QHBoxLayout()

        # ── 左侧：章节选择 ──
        left_group = QGroupBox('1. 选择要合成的片段')
        left_layout = QVBoxLayout()

        toolbar = QHBoxLayout()
        self.btn_split = QPushButton('拆分')
        self.btn_split.setToolTip('解析 EPUB，显示所有章节和片段')
        self.btn_split.clicked.connect(self.split_books)

        self.btn_select_all = QPushButton('全选')
        self.btn_select_all.setEnabled(False)
        self.btn_select_all.clicked.connect(self.toggle_select_all)

        self.lbl_select_count = QLabel('')
        self.lbl_select_count.setStyleSheet('color: gray;')

        toolbar.addWidget(self.btn_split)
        toolbar.addWidget(self.btn_select_all)
        toolbar.addStretch()
        toolbar.addWidget(self.lbl_select_count)
        left_layout.addLayout(toolbar)

        self.chapter_tree = QTreeWidget()
        self.chapter_tree.setHeaderLabels(['章节 / 片段'])
        self.chapter_tree.itemChanged.connect(self._on_item_changed)
        left_layout.addWidget(self.chapter_tree)

        left_group.setLayout(left_layout)
        top_layout.addWidget(left_group, stretch=1)

        # ── 右侧：音色设置 ──
        right_group = QGroupBox('2. 音色设置')
        right_layout = QVBoxLayout()
        self.voice_tabs = QTabWidget()

        self._init_preset_tab()
        self._init_clone_tab()
        self._init_design_tab()

        self.voice_tabs.addTab(self.tab_preset, '预置音色')
        self.voice_tabs.addTab(self.tab_clone, '音色克隆')
        self.voice_tabs.addTab(self.tab_design, '音色设计')

        right_layout.addWidget(self.voice_tabs)
        right_group.setLayout(right_layout)
        top_layout.addWidget(right_group, stretch=1)

        main_layout.addLayout(top_layout)

        # ── 日志与进度 ──
        self.log_output = QTextEdit()
        self.log_output.setReadOnly(True)
        self.log_output.setMaximumHeight(100)
        main_layout.addWidget(QLabel('运行日志:'))
        main_layout.addWidget(self.log_output)

        self.progress_bar = QProgressBar()
        self.progress_bar.setValue(0)
        main_layout.addWidget(self.progress_bar)

        # ── 底部按钮 ──
        btn_layout = QHBoxLayout()
        self.btn_start = QPushButton('开始合成')
        self.btn_pause = QPushButton('暂停')
        self.btn_resume = QPushButton('继续')
        self.btn_clear_cache = QPushButton('清除缓存')
        self.btn_config = QPushButton('插件设置')
        self.btn_close = QPushButton('关闭')

        self.btn_pause.setEnabled(False)
        self.btn_resume.setEnabled(False)
        self.btn_start.setEnabled(False)

        btn_layout.addWidget(self.btn_start)
        btn_layout.addWidget(self.btn_pause)
        btn_layout.addWidget(self.btn_resume)
        btn_layout.addWidget(self.btn_clear_cache)
        btn_layout.addWidget(self.btn_config)
        btn_layout.addStretch()
        btn_layout.addWidget(self.btn_close)

        main_layout.addLayout(btn_layout)

        self.btn_start.clicked.connect(self.start_conversion)
        self.btn_pause.clicked.connect(self.pause_conversion)
        self.btn_resume.clicked.connect(self.resume_conversion)
        self.btn_clear_cache.clicked.connect(self.clear_cache)
        self.btn_config.clicked.connect(self.config)
        self.btn_close.clicked.connect(self.reject)

    def _init_preset_tab(self):
        self.tab_preset = QWidget()
        layout = QVBoxLayout()
        layout.addWidget(QLabel('选择小米官方预置音色:'))
        self.preset_combo = QComboBox()
        self.preset_combo.addItems(PRESET_VOICES)
        default_voice = prefs['default_voice']
        for i in range(self.preset_combo.count()):
            if default_voice in self.preset_combo.itemText(i):
                self.preset_combo.setCurrentIndex(i)
                break
        layout.addWidget(self.preset_combo)
        layout.addStretch()
        self.tab_preset.setLayout(layout)

    def _init_clone_tab(self):
        self.tab_clone = QWidget()
        layout = QVBoxLayout()

        layout.addWidget(QLabel('选择参考音频文件，API 将复刻该音色:'))
        layout.addWidget(QLabel('支持 MP3、WAV 格式。'))

        self.clone_audio_path = QLineEdit()
        self.clone_audio_path.setPlaceholderText('点击「浏览」选择参考音频...')
        self.clone_audio_path.setReadOnly(True)

        btn_browse = QPushButton('浏览')
        btn_browse.clicked.connect(self.browse_clone_audio)

        self.btn_play_ref = QPushButton('播放')
        self.btn_play_ref.setEnabled(False)
        self.btn_play_ref.clicked.connect(self.play_clone_audio)

        row1 = QHBoxLayout()
        row1.addWidget(self.clone_audio_path)
        row1.addWidget(btn_browse)
        row1.addWidget(self.btn_play_ref)
        layout.addLayout(row1)

        layout.addWidget(QLabel(''))
        layout.addWidget(QLabel('风格提示词（可选）:'))
        self.clone_prompt = QTextEdit()
        self.clone_prompt.setMaximumHeight(60)
        self.clone_prompt.setPlaceholderText(
            '例如：用温柔的语气说话，语速稍慢，带着淡淡的笑意...')
        self.clone_prompt.setToolTip(
            '在 user message 中传入自然语言指令，控制克隆音色的说话风格。\n'
            '留空则不做风格控制，仅使用参考音频的音色。')
        layout.addWidget(self.clone_prompt)

        layout.addWidget(QLabel(''))
        layout.addWidget(QLabel('──── 试听音色 ────'))

        layout.addWidget(QLabel('输入试听文本:'))
        self.preview_text = QTextEdit()
        self.preview_text.setMaximumHeight(80)
        self.preview_text.setPlaceholderText('输入一句话试听克隆效果...')
        layout.addWidget(self.preview_text)

        preview_row = QHBoxLayout()
        self.btn_preview = QPushButton('试听合成')
        self.btn_preview.clicked.connect(self.preview_clone_voice)
        self.lbl_preview_status = QLabel('')

        preview_row.addWidget(self.btn_preview)
        preview_row.addWidget(self.lbl_preview_status)
        preview_row.addStretch()
        layout.addLayout(preview_row)

        layout.addStretch()
        self.tab_clone.setLayout(layout)

    def _init_design_tab(self):
        self.tab_design = QWidget()
        layout = QVBoxLayout()
        layout.addWidget(QLabel('用文字描述你想要的音色，模型将自动生成:'))
        self.design_prompt = QTextEdit()
        self.design_prompt.setPlaceholderText(
            '例如：一位年迈的老先生，说带北方口音的普通话，'
            '语速缓慢而沉稳，嗓音略带沙哑和沧桑感，'
            '仿佛一位饱经风霜的老爷爷在讲故事。'
        )
        layout.addWidget(self.design_prompt)
        self.tab_design.setLayout(layout)

    # ── 拆分与选择 ───────────────────────────────────────────────

    def split_books(self):
        self.chapter_tree.clear()
        self.chapters_data = []
        self.btn_select_all.setEnabled(False)
        self.btn_start.setEnabled(False)
        self.lbl_select_count.setText('')

        for book_id in self.book_ids:
            formats = self.db.formats(book_id)
            if not formats or 'EPUB' not in formats:
                continue

            title = self.db.field_for('title', book_id)
            epub_path = self.db.format_abspath(book_id, 'EPUB')
            if not epub_path or not os.path.exists(epub_path):
                continue

            self.append_log(f"正在解析: {title} ...")
            parser = BookParser(epub_path)
            chapters = parser.parse_and_chunk()

            if not chapters:
                continue

            self.chapters_data.append({
                'book_id': book_id,
                'book_title': title,
                'chapters': chapters,
            })

            book_item = QTreeWidgetItem(self.chapter_tree)
            book_item.setText(0, f"[{title}]")
            book_item.setData(0, TREE_ROLE_TYPE, TYPE_BOOK)
            book_item.setFlags(
                book_item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            book_item.setCheckState(0, Qt.CheckState.Checked)

            for chap_idx, chapter in enumerate(chapters):
                chap_title = chapter['title']
                chap_item = QTreeWidgetItem(book_item)
                chap_item.setText(0, f"  {chap_title}  ({len(chapter['chunks'])}段)")
                chap_item.setData(0, TREE_ROLE_TYPE, TYPE_CHAPTER)
                chap_item.setData(0, Qt.ItemDataRole.UserRole + 1,
                                  (book_id, chap_idx))
                chap_item.setFlags(
                    chap_item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
                chap_item.setCheckState(0, Qt.CheckState.Checked)

                for chunk_idx, text in enumerate(chapter['chunks']):
                    preview = text[:80].replace('\n', ' ')
                    chunk_item = QTreeWidgetItem(chap_item)
                    chunk_item.setText(0, f"    {preview}...")
                    chunk_item.setData(0, TREE_ROLE_TYPE, TYPE_CHUNK)
                    chunk_item.setData(0, Qt.ItemDataRole.UserRole + 1,
                                       (book_id, chap_idx, chunk_idx))
                    chunk_item.setFlags(
                        chunk_item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
                    chunk_item.setCheckState(0, Qt.CheckState.Checked)

                self.chapter_tree.expandItem(book_item)

        self.append_log("拆分完成，请在树中勾选要合成的片段。")
        self.btn_select_all.setEnabled(True)
        self.btn_start.setEnabled(True)
        self.btn_select_all.setText('取消全选')
        self._update_select_count()

    def _on_item_changed(self, item, column):
        """子节点勾选变化时同步父节点状态；父节点变化时同步子节点。"""
        if self._updating_checkboxes:
            return
        self._updating_checkboxes = True
        try:
            item_type = item.data(0, TREE_ROLE_TYPE)
            check_state = item.checkState(0)

            # 父节点 → 同步所有子孙
            if item_type in (TYPE_BOOK, TYPE_CHAPTER) and check_state != Qt.CheckState.PartiallyChecked:
                self._set_children_check(item, check_state)

            # 子节点变化 → 更新父节点状态
            parent = item.parent()
            if parent is not None:
                self._update_parent_check(parent)

            self._update_select_count()
        finally:
            self._updating_checkboxes = False

    def _set_children_check(self, parent, state):
        for i in range(parent.childCount()):
            child = parent.child(i)
            child.setCheckState(0, state)
            self._set_children_check(child, state)

    def _update_parent_check(self, parent):
        checked = 0
        partial = 0
        total = parent.childCount()
        for i in range(total):
            s = parent.child(i).checkState(0)
            if s == Qt.CheckState.Checked:
                checked += 1
            elif s == Qt.CheckState.PartiallyChecked:
                partial += 1
        if checked == total:
            parent.setCheckState(0, Qt.CheckState.Checked)
        elif checked == 0 and partial == 0:
            parent.setCheckState(0, Qt.CheckState.Unchecked)
        else:
            parent.setCheckState(0, Qt.CheckState.PartiallyChecked)

        grandparent = parent.parent()
        if grandparent is not None:
            self._update_parent_check(grandparent)

    def toggle_select_all(self):
        if self.btn_select_all.text() == '全选':
            new_state = Qt.CheckState.Checked
            self.btn_select_all.setText('取消全选')
        else:
            new_state = Qt.CheckState.Unchecked
            self.btn_select_all.setText('全选')

        self._updating_checkboxes = True
        try:
            for i in range(self.chapter_tree.topLevelItemCount()):
                book_item = self.chapter_tree.topLevelItem(i)
                book_item.setCheckState(0, new_state)
                self._set_children_check(book_item, new_state)
            self._update_select_count()
        finally:
            self._updating_checkboxes = False

    def _update_select_count(self):
        total = 0
        selected = 0
        for i in range(self.chapter_tree.topLevelItemCount()):
            book_item = self.chapter_tree.topLevelItem(i)
            for j in range(book_item.childCount()):
                chap_item = book_item.child(j)
                for k in range(chap_item.childCount()):
                    total += 1
                    if chap_item.child(k).checkState(0) == Qt.CheckState.Checked:
                        selected += 1
        self.lbl_select_count.setText(f'已选: {selected}/{total}')

    def _collect_selected_ids(self):
        """收集所有勾选的 chunk ID 集合。"""
        selected = set()
        for i in range(self.chapter_tree.topLevelItemCount()):
            book_item = self.chapter_tree.topLevelItem(i)
            for j in range(book_item.childCount()):
                chap_item = book_item.child(j)
                book_id, chap_idx = chap_item.data(
                    0, Qt.ItemDataRole.UserRole + 1)
                for k in range(chap_item.childCount()):
                    chunk_item = chap_item.child(k)
                    if chunk_item.checkState(0) == Qt.CheckState.Checked:
                        _, _, chunk_idx = chunk_item.data(
                            0, Qt.ItemDataRole.UserRole + 1)
                        chunk_id = f"book{book_id}_chap{chap_idx:04d}_chunk{chunk_idx:04d}"
                        selected.add(chunk_id)
        return selected

    # ── 浏览 / 播放 / 试听 ────────────────────────────────────────

    def browse_clone_audio(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            '选择参考音频文件',
            '',
            '音频文件 (*.mp3 *.wav);;MP3 (*.mp3);;WAV (*.wav);;所有文件 (*)'
        )
        if file_path:
            self.clone_audio_path.setText(file_path)
            self.btn_play_ref.setEnabled(True)

    def play_clone_audio(self):
        path = self.clone_audio_path.text().strip()
        if path and os.path.exists(path):
            QDesktopServices.openUrl(QUrl.fromLocalFile(path))

    def preview_clone_voice(self):
        audio_path = self.clone_audio_path.text().strip()
        if not audio_path:
            self.lbl_preview_status.setText('请先选择参考音频。')
            return

        text = self.preview_text.toPlainText().strip()
        if not text:
            self.lbl_preview_status.setText('请输入试听文本。')
            return

        if not prefs['api_key']:
            self.lbl_preview_status.setText('请先配置 API Key。')
            return

        self.btn_preview.setEnabled(False)
        self.lbl_preview_status.setText('正在合成试听...')

        if prefs['output_dir']:
            output_dir = prefs['output_dir']
        elif prefs['workspace_dir']:
            output_dir = prefs['workspace_dir']
        else:
            from calibre.utils.config import config_dir
            output_dir = os.path.join(config_dir, 'mimo_tts_workspace')

        clone_prompt = self.clone_prompt.toPlainText().strip()
        self.preview_worker = PreviewCloneWorker(
            prefs['api_key'], audio_path, text, output_dir, clone_prompt)
        self.preview_worker.finished_signal.connect(self.on_preview_finished)
        self.preview_worker.start()

    def on_preview_finished(self, success, result):
        self.btn_preview.setEnabled(True)
        if success:
            self.lbl_preview_status.setText(f'已保存: {result}')
            QDesktopServices.openUrl(QUrl.fromLocalFile(result))
        else:
            self.lbl_preview_status.setText(f'试听失败: {result}')

    # ── 书库加载 ─────────────────────────────────────────────────

    def load_book_data(self):
        if not prefs['api_key']:
            self.append_log("警告：请先在插件设置中配置 小米 TTS API Key！")

        for book_id in self.book_ids:
            title = self.db.field_for('title', book_id)
            author = self.db.field_for('authors', book_id)
            book_item = QTreeWidgetItem(self.chapter_tree)
            book_item.setText(0, f"{title} - {', '.join(author)}")
            book_item.setFlags(book_item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            book_item.setCheckState(0, Qt.CheckState.Checked)

            formats = self.db.formats(book_id)
            if formats and 'EPUB' in formats:
                hint = QTreeWidgetItem(book_item)
                hint.setText(0, "  点击「拆分」解析章节")
                hint.setFlags(Qt.ItemFlag.NoItemFlags)
            else:
                hint = QTreeWidgetItem(book_item)
                hint.setText(0, "  未找到 EPUB 格式，请先在 Calibre 中转换")
                hint.setFlags(Qt.ItemFlag.NoItemFlags)

            self.chapter_tree.expandItem(book_item)

    # ── 日志 / 配置 / 缓存 ───────────────────────────────────────

    def append_log(self, text):
        self.log_output.append(text)
        self.log_output.verticalScrollBar().setValue(
            self.log_output.verticalScrollBar().maximum())

    def config(self):
        self.do_user_config(parent=self)

    def clear_cache(self):
        reply = QMessageBox.question(
            self, '确认清除缓存',
            '将删除所有之前的音频碎片和断点续传进度，\n'
            '正在进行的合成任务不受影响。\n\n确定要清除吗？',
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No)
        if reply != QMessageBox.StandardButton.Yes:
            return

        if prefs['workspace_dir']:
            workspace = os.path.join(prefs['workspace_dir'], 'mimo_tts_workspace')
        else:
            from calibre.utils.config import config_dir
            workspace = os.path.join(config_dir, 'mimo_tts_workspace')
        if os.path.exists(workspace):
            try:
                shutil.rmtree(workspace)
                self.append_log(f"缓存已清除: {workspace}")
            except Exception as e:
                self.append_log(f"清除缓存失败: {e}")
        else:
            self.append_log("没有需要清除的缓存。")

    # ── 合成控制 ─────────────────────────────────────────────────

    def start_conversion(self):
        if not prefs['api_key']:
            self.append_log("错误：缺少 API Key，无法开始。")
            return

        if self.chapters_data is None:
            self.append_log("错误：请先点击「拆分」解析 EPUB。")
            return

        selected_ids = self._collect_selected_ids()
        if not selected_ids:
            self.append_log("错误：没有选中任何片段，请在树中勾选要合成的片段。")
            return

        tab_idx = self.voice_tabs.currentIndex()
        if tab_idx == 0:
            mode = 'preset'
            voice_text = self.preset_combo.currentText()
            voice = voice_text.split()[0]
            clone_prompt = ''
        elif tab_idx == 1:
            mode = 'clone'
            voice = self.clone_audio_path.text().strip()
            if not voice:
                self.append_log("错误：请先选择参考音频文件。")
                return
            if not voice.lower().endswith(('.mp3', '.wav')):
                self.append_log("错误：参考音频仅支持 MP3 或 WAV 格式。")
                return
            clone_prompt = self.clone_prompt.toPlainText().strip()
        else:
            mode = 'design'
            voice = self.design_prompt.toPlainText().strip()
            clone_prompt = ''
            if not voice:
                self.append_log("错误：请输入音色描述文本。")
                return

        self.append_log(
            f"初始化合成任务 (模式: {mode}, 片段: {len(selected_ids)})...")
        self.btn_start.setEnabled(False)
        self.btn_pause.setEnabled(True)
        self.btn_resume.setEnabled(False)

        settings = {
            'mode': mode,
            'voice': voice,
            'clone_prompt': clone_prompt,
            'api_key': prefs['api_key'],
            'max_workers': prefs['max_workers'],
            'ffmpeg_path': prefs['ffmpeg_path'],
            'output_dir': prefs['output_dir'],
            'workspace_dir': prefs['workspace_dir'],
            'chapters_data': self.chapters_data,
            'selected_ids': selected_ids,
        }

        from calibre_plugins.mimo_tts_plugin.worker import TTSWorker

        self.worker = TTSWorker(self.db, settings)
        self.worker.progress_updated.connect(self.on_progress)
        self.worker.log_updated.connect(self.append_log)
        self.worker.finished_signal.connect(self.on_finished)
        self.worker.start()

    def pause_conversion(self):
        if self.worker is not None:
            self.worker.pause()
            self.btn_pause.setEnabled(False)
            self.btn_resume.setEnabled(True)

    def resume_conversion(self):
        if self.worker is not None:
            self.worker.resume()
            self.btn_pause.setEnabled(True)
            self.btn_resume.setEnabled(False)

    def on_progress(self, percent):
        self.progress_bar.setValue(percent)

    def on_finished(self, success, message):
        self.btn_start.setEnabled(True)
        self.btn_pause.setEnabled(False)
        self.btn_resume.setEnabled(False)
        if success:
            self.append_log(f"✅ 合成完成: {message}")
            self.progress_bar.setValue(100)
        else:
            self.append_log(f"❌ 发生错误: {message}")

    def reject(self):
        if self.worker is not None and self.worker.isRunning():
            self.worker.stop()
            self.worker.wait(3000)
        if self.preview_worker is not None and self.preview_worker.isRunning():
            self.preview_worker.quit()
            self.preview_worker.wait(3000)
        super(MiMoTTSDialog, self).reject()
