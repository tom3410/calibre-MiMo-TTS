import os
import time
from qt.core import QThread, pyqtSignal
from concurrent.futures import ThreadPoolExecutor, as_completed

from calibre_plugins.mimo_tts_plugin.core.mimo_api import MiMoTTSClient
from calibre_plugins.mimo_tts_plugin.core.state_manager import StateManager
from calibre_plugins.mimo_tts_plugin.core.audio_merger import AudioMerger


class TTSWorker(QThread):
    progress_updated = pyqtSignal(int)
    log_updated = pyqtSignal(str)
    finished_signal = pyqtSignal(bool, str)

    def __init__(self, db, settings):
        super(TTSWorker, self).__init__()
        self.db = db
        self.settings = settings
        self.is_running = True
        self.is_paused = False

    def run(self):
        try:
            mode = self.settings['mode']
            voice = self.settings['voice']
            tts_client = MiMoTTSClient(self.settings['api_key'])

            chapters_data = self.settings['chapters_data']
            selected_ids = self.settings['selected_ids']

            filtered_books = self._filter_chapters(chapters_data, selected_ids)
            if not filtered_books:
                self.finished_signal.emit(False, "没有选中的片段。")
                return

            total_books = len(filtered_books)
            total_tasks = sum(
                sum(len(ch['chunks']) for ch in book['chapters'])
                for book in filtered_books)
            completed_tasks = 0

            for book_index, book_data in enumerate(filtered_books):
                if not self.is_running:
                    break

                book_id = book_data['book_id']
                title = book_data['book_title']
                authors = self.db.field_for('authors', book_id)
                author = authors[0] if authors else "Unknown"

                self.log_updated.emit(
                    f"====== 开始处理 [{book_index + 1}/{total_books}]: {title} ======")

                base_workspace = self.settings.get('workspace_dir', '')
                if base_workspace:
                    workspace_dir = os.path.join(
                        base_workspace, 'mimo_tts_workspace', f"book_{book_id}")
                else:
                    from calibre.utils.config import config_dir
                    workspace_dir = os.path.join(
                        config_dir, 'mimo_tts_workspace', f"book_{book_id}")
                os.makedirs(workspace_dir, exist_ok=True)

                state = StateManager(workspace_dir)
                tasks = state.initialize_tasks(book_data['chapters'])
                book_total = len(tasks)
                book_completed = state.get_completed_count()

                self.log_updated.emit(
                    f"分段完成：{book_total} 片段，已完成 {book_completed}。")

                max_workers = self.settings.get('max_workers', 10)
                self.log_updated.emit(
                    f"并发合成中 (模式: {mode}, Worker: {max_workers})...")

                pending_tasks = [t for t in tasks if t['status'] != 'done']

                clone_prompt = self.settings.get('clone_prompt', '')

                with ThreadPoolExecutor(max_workers=max_workers) as executor:
                    future_to_task = {}
                    for task in pending_tasks:
                        future = self._submit_task(
                            executor, tts_client, task, mode, voice,
                            clone_prompt)
                        future_to_task[future] = task

                    for future in as_completed(future_to_task):
                        if self.is_paused:
                            self.log_updated.emit("⏸️ 已暂停，等待继续...")
                            while self.is_paused and self.is_running:
                                time.sleep(0.5)
                            if self.is_running:
                                self.log_updated.emit("▶️ 继续合成...")

                        if not self.is_running:
                            executor.shutdown(
                                wait=False, cancel_futures=True)
                            break

                        task = future_to_task[future]
                        try:
                            future.result()
                            # 验证输出文件真实存在且非空（>1KB 才视为有效 MP3）
                            out_path = task['output_path']
                            if not os.path.exists(out_path) or os.path.getsize(out_path) < 1024:
                                raise Exception(
                                    f"输出文件无效 (大小: "
                                    f"{os.path.getsize(out_path) if os.path.exists(out_path) else '不存在'} 字节)")
                            state.mark_task_done(task['id'])
                            completed_tasks += 1
                            book_completed += 1
                            progress = int(
                                (completed_tasks / total_tasks) * 90)
                            self.progress_updated.emit(progress)
                        except Exception as e:
                            self.log_updated.emit(
                                f"❌ 片段 {task['id']} 失败: {str(e)}")

                if not self.is_running:
                    continue

                if book_completed == book_total:
                    self.log_updated.emit("合成完毕，正在生成 M4B...")

                    output_dir = self.settings.get('output_dir', '')
                    if output_dir:
                        os.makedirs(output_dir, exist_ok=True)
                        final_m4b_path = os.path.join(
                            output_dir, f"{title}.m4b")
                    else:
                        final_m4b_path = os.path.join(
                            workspace_dir, f"{title}.m4b")

                    merger = AudioMerger(
                        workspace_dir, self.settings['ffmpeg_path'])
                    merger.generate_m4b(
                        book_data['chapters'], title, author, final_m4b_path)

                    self.log_updated.emit(
                        f"🎉 M4B 生成成功: {final_m4b_path}")
                    self.progress_updated.emit(100)
                else:
                    self.log_updated.emit("⚠️ 部分片段失败，跳过合并。")

            if self.is_running:
                self.finished_signal.emit(True, "全部处理完成！")
            else:
                self.finished_signal.emit(False, "任务已中止。")

        except Exception as e:
            import traceback
            self.finished_signal.emit(
                False, f"严重错误: {str(e)}\n{traceback.format_exc()}")

    def _submit_task(self, executor, tts_client, task, mode, voice,
                     clone_prompt=''):
        if mode == 'preset':
            return executor.submit(
                tts_client.synthesize_preset,
                task['text'], task['output_path'], voice)
        elif mode == 'clone':
            return executor.submit(
                tts_client.synthesize_clone,
                task['text'], task['output_path'], voice, clone_prompt)
        elif mode == 'design':
            return executor.submit(
                tts_client.synthesize_design,
                task['text'], task['output_path'], voice)
        else:
            raise Exception(f"未知的合成模式: {mode}")

    def _filter_chapters(self, chapters_data, selected_ids):
        filtered = []
        for book_data in chapters_data:
            filtered_chapters = []
            for chap_idx, chapter in enumerate(book_data['chapters']):
                filtered_chunks = []
                for chunk_idx, text in enumerate(chapter['chunks']):
                    chunk_id = f"book{book_data['book_id']}_chap{chap_idx:04d}_chunk{chunk_idx:04d}"
                    if chunk_id in selected_ids:
                        filtered_chunks.append(text)
                if filtered_chunks:
                    filtered_chapters.append({
                        'title': chapter['title'],
                        'chunks': filtered_chunks,
                    })
            if filtered_chapters:
                filtered.append({
                    'book_id': book_data['book_id'],
                    'book_title': book_data['book_title'],
                    'chapters': filtered_chapters,
                })
        return filtered

    def stop(self):
        self.is_running = False
        self.is_paused = False

    def pause(self):
        self.is_paused = True

    def resume(self):
        self.is_paused = False
