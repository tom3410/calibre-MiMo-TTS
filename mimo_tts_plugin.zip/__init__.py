from calibre.customize import InterfaceActionBase


class MiMoTTSPlugin(InterfaceActionBase):
    name = 'MiMo TTS'
    description = '基于小米语音合成 API v2.5，将电子书自动转换为 M4B 有声书。'
    supported_platforms = ['windows', 'osx', 'linux']
    author = 'Your Name'
    version = (1, 0, 0)
    minimum_calibre_version = (6, 0, 0)

    actual_plugin = 'calibre_plugins.mimo_tts_plugin.action:MiMoTTSAction'

    def is_customizable(self):
        return True

    def config_widget(self):
        from calibre_plugins.mimo_tts_plugin.config import ConfigWidget
        return ConfigWidget()

    def save_settings(self, config_widget):
        config_widget.save_settings()
        ac = self.actual_plugin_
        if ac is not None:
            ac.apply_settings()
