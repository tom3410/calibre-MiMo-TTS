from calibre.gui2.actions import InterfaceAction
from calibre.gui2 import error_dialog


class MiMoTTSAction(InterfaceAction):
    name = 'MiMo TTS'
    action_spec = ('MiMo TTS', None, '将选中的电子书转换为 M4B 有声书', None)

    def genesis(self):
        icon = get_icons('images/icon.png', 'MiMo TTS')
        self.qaction.setIcon(icon)
        self.qaction.triggered.connect(self.show_dialog)

    def show_dialog(self):
        rows = self.gui.library_view.selectionModel().selectedRows()
        if not rows:
            error_dialog(self.gui, '未选中书籍', '请先在书库中选中至少一本你要转换的电子书。', show=True)
            return

        db = self.gui.current_db.new_api
        book_ids = [self.gui.library_view.model().id(row) for row in rows]

        base_plugin_object = self.interface_action_base_plugin
        do_user_config = base_plugin_object.do_user_config

        from calibre_plugins.mimo_tts_plugin.ui import MiMoTTSDialog
        self.dialog = MiMoTTSDialog(self.gui, self.qaction.icon(), do_user_config, db, book_ids)
        self.dialog.show()

    def apply_settings(self):
        from calibre_plugins.mimo_tts_plugin.config import prefs
        prefs
