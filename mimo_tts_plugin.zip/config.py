from qt.core import (QWidget, QFormLayout, QHBoxLayout,
                     QLabel, QLineEdit, QPushButton, QSpinBox,
                     QFileDialog)
from calibre.utils.config import JSONConfig

prefs = JSONConfig('plugins/mimo_tts_settings')

prefs.defaults['api_key'] = ''
prefs.defaults['max_workers'] = 10
prefs.defaults['ffmpeg_path'] = 'ffmpeg'
prefs.defaults['default_voice'] = 'mimo_default'
prefs.defaults['output_dir'] = ''
prefs.defaults['workspace_dir'] = ''


class ConfigWidget(QWidget):
    def __init__(self):
        super(ConfigWidget, self).__init__()
        self.init_ui()

    def init_ui(self):
        layout = QFormLayout()
        self.setLayout(layout)

        self.api_key_edit = QLineEdit(self)
        self.api_key_edit.setText(prefs['api_key'])
        self.api_key_edit.setEchoMode(QLineEdit.EchoMode.Password)
        layout.addRow(QLabel('小米 TTS API Key:'), self.api_key_edit)

        self.max_workers_spin = QSpinBox(self)
        self.max_workers_spin.setRange(1, 20)
        self.max_workers_spin.setValue(prefs['max_workers'])
        self.max_workers_spin.setToolTip("建议设置在 5-10 之间，过高可能触发 API 限流。")
        layout.addRow(QLabel('并发合成任务数:'), self.max_workers_spin)

        self.ffmpeg_path_edit = QLineEdit(self)
        self.ffmpeg_path_edit.setText(prefs['ffmpeg_path'])
        self.ffmpeg_path_edit.setToolTip(
            "如果已添加到系统环境变量，填 ffmpeg 即可；否则请填写绝对路径。")
        layout.addRow(QLabel('FFmpeg 执行路径:'), self.ffmpeg_path_edit)

        self.default_voice_edit = QLineEdit(self)
        self.default_voice_edit.setText(prefs['default_voice'])
        self.default_voice_edit.setToolTip(
            "例如: mimo_default, 冰糖, 茉莉, Mia 等")
        layout.addRow(QLabel('默认预置音色 ID:'), self.default_voice_edit)

        # 输出目录：路径 + 浏览按钮
        output_row = QHBoxLayout()
        self.output_dir_edit = QLineEdit(self)
        self.output_dir_edit.setText(prefs['output_dir'])
        self.output_dir_edit.setPlaceholderText('留空则保存在工作目录下')
        self.output_dir_edit.setToolTip(
            'M4B 有声书的保存目录。留空则保存在 Calibre 配置目录下。')

        btn_browse_dir = QPushButton('浏览', self)
        btn_browse_dir.clicked.connect(self.browse_output_dir)

        output_row.addWidget(self.output_dir_edit)
        output_row.addWidget(btn_browse_dir)
        layout.addRow(QLabel('M4B 输出目录:'), output_row)

        # 缓存目录：路径 + 浏览按钮
        workspace_row = QHBoxLayout()
        self.workspace_dir_edit = QLineEdit(self)
        self.workspace_dir_edit.setText(prefs['workspace_dir'])
        self.workspace_dir_edit.setPlaceholderText('留空则使用 Calibre 配置目录')
        self.workspace_dir_edit.setToolTip(
            '音频碎片和断点续传进度的存储目录。建议设置在空间充裕的磁盘上。')

        btn_browse_workspace = QPushButton('浏览', self)
        btn_browse_workspace.clicked.connect(self.browse_workspace_dir)

        workspace_row.addWidget(self.workspace_dir_edit)
        workspace_row.addWidget(btn_browse_workspace)
        layout.addRow(QLabel('缓存目录:'), workspace_row)

    def browse_workspace_dir(self):
        folder = QFileDialog.getExistingDirectory(
            self, '选择缓存目录', self.workspace_dir_edit.text())
        if folder:
            self.workspace_dir_edit.setText(folder)

    def browse_output_dir(self):
        folder = QFileDialog.getExistingDirectory(
            self, '选择 M4B 输出目录', self.output_dir_edit.text())
        if folder:
            self.output_dir_edit.setText(folder)

    def save_settings(self):
        prefs['api_key'] = self.api_key_edit.text().strip()
        prefs['max_workers'] = self.max_workers_spin.value()
        prefs['ffmpeg_path'] = self.ffmpeg_path_edit.text().strip()
        prefs['default_voice'] = self.default_voice_edit.text().strip()
        prefs['output_dir'] = self.output_dir_edit.text().strip()
        prefs['workspace_dir'] = self.workspace_dir_edit.text().strip()
