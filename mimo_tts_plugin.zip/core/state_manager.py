# mimo_tts_plugin/core/state_manager.py

import os
import json
import threading

class StateManager:
    """
    负责管理和持久化合成任务的状态，实现断点续传功能。
    保证多线程更新状态时的线程安全。
    """
    def __init__(self, workspace_dir):
        self.workspace_dir = workspace_dir
        self.state_file = os.path.join(workspace_dir, 'tasks.json')
        self.audio_dir = os.path.join(workspace_dir, 'audio_chunks')
        self.lock = threading.Lock()
        self.tasks = []

        # 确保存放音频碎片的目录存在
        os.makedirs(self.audio_dir, exist_ok=True)

    def initialize_tasks(self, chapters_data):
        """
        根据解析好的章节数据初始化任务列表。
        如果状态文件已存在，则加载现有状态并验证文件完整性。
        """
        # 如果存在之前的进度，加载并验证缓存文件
        if os.path.exists(self.state_file):
            try:
                with open(self.state_file, 'r', encoding='utf-8') as f:
                    self.tasks = json.load(f)
                # 验证每个标记为 done 的任务对应的音频文件是否真实存在且有效
                recovered = 0
                for task in self.tasks:
                    if task['status'] == 'done':
                        path = task['output_path']
                        if not os.path.exists(path) or os.path.getsize(path) < 1024:
                            task['status'] = 'pending'
                            recovered += 1
                if recovered:
                    self._save_tasks()
                return self.tasks
            except Exception as e:
                print(f"读取原有状态文件失败，将重新初始化: {e}")

        # 如果不存在，或者读取失败，则展平章节数据，构建全新的任务列表
        self.tasks = []
        for chap_idx, chapter in enumerate(chapters_data):
            for chunk_idx, text in enumerate(chapter['chunks']):
                task_id = f"chap{chap_idx:04d}_chunk{chunk_idx:04d}"
                output_filename = f"{task_id}.mp3"
                output_path = os.path.join(self.audio_dir, output_filename)
                
                self.tasks.append({
                    'id': task_id,
                    'chap_idx': chap_idx,
                    'chunk_idx': chunk_idx,
                    'chap_title': chapter['title'],
                    'text': text,
                    'output_path': output_path,
                    'status': 'pending' # 状态: pending, done, error
                })
        
        self._save_tasks()
        return self.tasks

    def mark_task_done(self, task_id):
        """
        将指定任务标记为已完成，并保存到本地。
        使用 Lock 保证多线程并发写入时的安全。
        """
        with self.lock:
            for task in self.tasks:
                if task['id'] == task_id:
                    task['status'] = 'done'
                    break
            self._save_tasks_without_lock()

    def mark_task_error(self, task_id):
        """
        将指定任务标记为错误。
        """
        with self.lock:
            for task in self.tasks:
                if task['id'] == task_id:
                    task['status'] = 'error'
                    break
            self._save_tasks_without_lock()

    def get_completed_count(self):
        """
        获取已成功完成的任务数量。
        """
        return sum(1 for task in self.tasks if task['status'] == 'done')

    def _save_tasks(self):
        """带锁保存 JSON（外部调用）"""
        with self.lock:
            self._save_tasks_without_lock()

    def _save_tasks_without_lock(self):
        """无锁保存 JSON（内部调用，调用前必须先获取锁）"""
        # 先写入临时文件，再重命名，避免写入中途断电导致文件损坏
        temp_file = self.state_file + '.tmp'
        with open(temp_file, 'w', encoding='utf-8') as f:
            json.dump(self.tasks, f, ensure_ascii=False, indent=2)
        os.replace(temp_file, self.state_file)