# mimo_tts_plugin/core/audio_merger.py

import os
import json
import subprocess
import sys

class AudioMerger:
    """
    负责将下载的音频碎片合成、转换，并写入章节元数据，最终输出为 M4B 文件。
    """
    def __init__(self, workspace_dir, ffmpeg_path='ffmpeg'):
        self.workspace_dir = workspace_dir
        self.ffmpeg_path = ffmpeg_path
        
        # 自动推断 ffprobe 的路径 (它与 ffmpeg 通常在同一目录下)
        if ffmpeg_path.lower().endswith('ffmpeg.exe'):
            self.ffprobe_path = ffmpeg_path[:-10] + 'ffprobe.exe'
        elif ffmpeg_path.lower().endswith('ffmpeg'):
            self.ffprobe_path = ffmpeg_path[:-6] + 'ffprobe'
        else:
            self.ffprobe_path = 'ffprobe' # 依赖环境变量

    def _subprocess_kwargs(self):
        """跨平台 subprocess 参数：Windows 下隐藏控制台弹窗。"""
        kwargs = {}
        if sys.platform == 'win32':
            kwargs['creationflags'] = subprocess.CREATE_NO_WINDOW
        return kwargs

    def get_audio_duration(self, file_path):
        """
        使用 ffprobe 获取单个音频文件的时长（秒）。
        """
        cmd = [
            self.ffprobe_path,
            '-v', 'error',
            '-show_entries', 'format=duration',
            '-of', 'default=noprint_wrappers=1:nokey=1',
            file_path
        ]
        try:
            result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                    text=True, check=True, **self._subprocess_kwargs())
            return float(result.stdout.strip())
        except Exception as e:
            print(f"获取音频时长失败 ({file_path}): {e}")
            return 0.0

    def generate_m4b(self, chapters_data, book_title, book_author, final_m4b_path):
        """
        核心方法：读取所有成功合成的碎片，生成 M4B。
        """
        state_file = os.path.join(self.workspace_dir, 'tasks.json')
        if not os.path.exists(state_file):
            raise Exception("未找到 tasks.json 任务状态文件，无法合并。")

        with open(state_file, 'r', encoding='utf-8') as f:
            tasks = json.load(f)

        # 检查是否所有任务都已完成
        if any(task['status'] != 'done' for task in tasks):
            raise Exception("存在未成功合成的音频片段，请先恢复并完成所有片段的合成。")

        # 合并前最终校验：确保所有音频文件真实存在且大小合理
        missing = []
        for task in tasks:
            path = task['output_path']
            if not os.path.exists(path) or os.path.getsize(path) < 1024:
                missing.append(task['id'])
        if missing:
            raise Exception(
                f"以下片段的音频文件缺失或无效，请重新合成：{', '.join(missing[:10])}"
                + (f" 等共 {len(missing)} 个" if len(missing) > 10 else ""))

        # 准备 FFmpeg 所需的中间文件
        concat_file = os.path.join(self.workspace_dir, 'concat.txt')
        metadata_file = os.path.join(self.workspace_dir, 'ffmetadata.txt')

        # 分组任务，按章节聚类
        grouped_tasks = {}
        for task in tasks:
            chap_idx = task['chap_idx']
            if chap_idx not in grouped_tasks:
                grouped_tasks[chap_idx] = []
            grouped_tasks[chap_idx].append(task)

        # 构建 metadata 和 concat 文件内容
        concat_lines = []
        metadata_lines = [
            ";FFMETADATA1",
            f"title={book_title}",
            f"artist={book_author}",
            ""
        ]

        current_time_ms = 0  # 当前时间的毫秒数

        for chap_idx in sorted(grouped_tasks.keys()):
            chap_tasks = grouped_tasks[chap_idx]
            # 排序确保音频切片顺序正确
            chap_tasks.sort(key=lambda x: x['chunk_idx']) 
            
            chap_title = chap_tasks[0]['chap_title']
            chap_start_ms = current_time_ms

            for task in chap_tasks:
                audio_path = task['output_path']
                # FFmpeg concat 要求路径中的反斜杠被转义，或者统一用正斜杠
                safe_path = audio_path.replace('\\', '/')
                concat_lines.append(f"file '{safe_path}'")
                
                # 累加时间
                duration_sec = self.get_audio_duration(audio_path)
                current_time_ms += int(duration_sec * 1000)

            chap_end_ms = current_time_ms

            # 写入该章节的元数据信息 (M4B 必须的章节标签)
            metadata_lines.extend([
                "[CHAPTER]",
                "TIMEBASE=1/1000",
                f"START={chap_start_ms}",
                f"END={chap_end_ms}",
                f"title={chap_title}",
                ""
            ])

        # 保存 concat 和 metadata 文件
        with open(concat_file, 'w', encoding='utf-8') as f:
            f.write("\n".join(concat_lines))
        with open(metadata_file, 'w', encoding='utf-8') as f:
            f.write("\n".join(metadata_lines))

        # 执行 FFmpeg 命令
        # -f concat: 使用合并协议
        # -safe 0: 允许绝对路径
        # -map_metadata 1: 将第二个输入(ffmetadata.txt)作为全局元数据
        # -c:a aac: 重新编码为 aac (M4B 标准编码)
        # -vn: 丢弃可能的视频轨(如封面)，保持纯音频
        cmd = [
            self.ffmpeg_path, '-y',
            '-f', 'concat', '-safe', '0', '-i', concat_file,
            '-i', metadata_file,
            '-map_metadata', '1',
            '-c:a', 'aac', '-b:a', '64k',  # 设定码率为64k，适合有声书，兼顾体积和音质
            '-vn',
            final_m4b_path
        ]

        try:
            process = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                     text=True, check=True, **self._subprocess_kwargs())
            print(f"合并完成: {final_m4b_path}")
        except subprocess.CalledProcessError as e:
            # 如果出错，打印出 FFmpeg 的报错信息
            print(f"FFmpeg 输出错误:\n{e.stderr}")
            raise Exception("FFmpeg 合并失败，请检查运行日志或 FFmpeg 路径配置。")
            
        # 合并完成后，可以选择清理临时文件（可选，如果需要调试建议保留）
        # os.remove(concat_file)
        # os.remove(metadata_file)