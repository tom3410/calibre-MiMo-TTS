# mimo_tts_plugin/core/book_parser.py

import zipfile
import xml.etree.ElementTree as ET
import re
import os
from urllib.parse import unquote
from bs4 import BeautifulSoup

class BookParser:
    """
    负责解析 EPUB 电子书，提取带顺序的文本，并进行智能分段。
    """
    def __init__(self, epub_path):
        self.epub_path = epub_path

    def parse_and_chunk(self, max_len=900):
        """
        主控方法：提取章节文本并进行切片
        返回格式: [
            {'title': '第一章', 'chunks': ['文本片段1', '文本片段2']},
            {'title': '第二章', 'chunks': ['文本片段1', '...']}
        ]
        """
        chapters_data = []
        chapters_html = self._extract_spine_html()
        
        for idx, (title, html_content) in enumerate(chapters_html):
            # 1. 使用 BeautifulSoup 提取纯文本
            soup = BeautifulSoup(html_content, 'html.parser')
            
            # 尝试获取更准确的章节标题
            h1_tag = soup.find(['h1', 'h2', 'h3'])
            if h1_tag and h1_tag.text.strip():
                chap_title = h1_tag.text.strip()
            else:
                title_tag = soup.find('title')
                chap_title = title_tag.text.strip() if title_tag else f"Chapter_{idx+1}"
            
            # 清理标题中的非法字符（用于后续保存文件）
            chap_title = re.sub(r'[\\/:*?"<>|]', '_', chap_title)

            # 获取页面纯文本，用换行符替换块级元素
            raw_text = soup.get_text(separator='\n')
            
            # 2. 智能分段
            chunks = self._smart_chunk(raw_text, max_len)
            
            if chunks:
                chapters_data.append({
                    'title': chap_title,
                    'chunks': chunks
                })
                
        return chapters_data

    def _smart_chunk(self, text, max_len=900):
        """
        智能分段：按句号、问号、叹号等进行切割，确保每个分段不超过 max_len 个字符
        """
        # 清理多余的空白字符
        text = re.sub(r'\s+', ' ', text).strip()
        if not text:
            return []

        # 使用正则保留分隔符进行切割，匹配中文和英文的句号、问号、叹号
        parts = re.split(r'([。？！.?!])', text)
        
        chunks = []
        current_chunk = ""

        # parts 的结构类似于: ['你好', '。', '世界', '！', '']
        for i in range(0, len(parts)-1, 2):
            sentence = parts[i] + parts[i+1]
            if len(current_chunk) + len(sentence) <= max_len:
                current_chunk += sentence
            else:
                if current_chunk:
                    chunks.append(current_chunk.strip())
                current_chunk = sentence
                
        # 处理可能剩余的最后一部分（没有标点符号结尾的情况）
        if len(parts) % 2 != 0 and parts[-1]:
            if len(current_chunk) + len(parts[-1]) <= max_len:
                current_chunk += parts[-1]
            else:
                if current_chunk:
                    chunks.append(current_chunk.strip())
                current_chunk = parts[-1]
                
        if current_chunk:
            chunks.append(current_chunk.strip())
            
        return chunks

    def _extract_spine_html(self):
        """
        读取 EPUB 结构，按照阅读顺序（Spine）提取所有 HTML 文件内容。
        """
        html_list = []
        try:
            with zipfile.ZipFile(self.epub_path, 'r') as zf:
                # 1. 读取 container.xml 找到 .opf 文件的路径
                container_xml = zf.read('META-INF/container.xml')
                root = ET.fromstring(container_xml)
                opf_path = None
                for rootfile in root.iter('{urn:oasis:names:tc:opendocument:xmlns:container}rootfile'):
                    opf_path = rootfile.attrib.get('full-path')
                    break
                    
                if not opf_path:
                    raise Exception("无法在 EPUB 中找到 OPF 文件。")

                opf_dir = os.path.dirname(opf_path)
                opf_content = zf.read(opf_path)
                
                # 去除 XML 的命名空间前缀，简化解析
                opf_str = re.sub(r'\sxmlns="[^"]+"', '', opf_content.decode('utf-8'))
                opf_root = ET.fromstring(opf_str)

                # 2. 解析 manifest (所有文件的清单)
                manifest = {}
                for item in opf_root.findall('.//manifest/item'):
                    item_id = item.attrib.get('id')
                    href = item.attrib.get('href')
                    manifest[item_id] = unquote(href) # 处理 URL 编码的路径

                # 3. 解析 spine (阅读顺序)
                spine_items = []
                for itemref in opf_root.findall('.//spine/itemref'):
                    spine_items.append(itemref.attrib.get('idref'))

                # 4. 按顺序提取文件内容
                for item_id in spine_items:
                    href = manifest.get(item_id)
                    if href:
                        # 拼装在 ZIP 包中的绝对路径
                        file_path = f"{opf_dir}/{href}" if opf_dir else href
                        try:
                            content = zf.read(file_path).decode('utf-8')
                            html_list.append((href, content))
                        except Exception:
                            # 忽略无法读取的部分（如图片）
                            continue

        except Exception as e:
            print(f"解析 EPUB 失败: {e}")
            
        return html_list