import json
import urllib.request
import urllib.error
import base64
import os
import time


class MiMoTTSClient:
    """小米语音合成 API v2.5 客户端，支持预置音色、音色克隆、音色设计三种模式。"""

    def __init__(self, api_key):
        self.api_key = api_key
        self.api_url = "https://api.xiaomimimo.com/v1/chat/completions"

    def synthesize_preset(self, text, output_path, voice, max_retries=3):
        """预置音色合成。voice 为音色名如 mimo_default、冰糖、Mia 等。"""
        if os.path.exists(output_path) and os.path.getsize(output_path) > 0:
            return

        payload = {
            "model": "mimo-v2.5-tts",
            "messages": [
                {"role": "assistant", "content": text}
            ],
            "audio": {
                "voice": voice,
                "format": "mp3"
            },
            "stream": False
        }
        self._do_request(payload, output_path, max_retries)

    def synthesize_clone(self, text, output_path, audio_file_path, clone_prompt='', max_retries=3):
        """音色克隆合成。audio_file_path 为参考音频的本地路径。
        clone_prompt 为可选的风格提示词，传入 user message 的 content 中。"""
        if os.path.exists(output_path) and os.path.getsize(output_path) > 0:
            return

        with open(audio_file_path, 'rb') as f:
            audio_bytes = f.read()

        ext = os.path.splitext(audio_file_path)[1].lower()
        if ext == '.mp3':
            mime_type = 'audio/mpeg'
        elif ext == '.wav':
            mime_type = 'audio/wav'
        else:
            raise Exception(f"不支持的参考音频格式: {ext}，请使用 MP3 或 WAV。")

        voice_b64 = base64.b64encode(audio_bytes).decode('utf-8')
        voice_data = f"data:{mime_type};base64,{voice_b64}"

        payload = {
            "model": "mimo-v2.5-tts-voiceclone",
            "messages": [
                {"role": "user", "content": clone_prompt or ""},
                {"role": "assistant", "content": text}
            ],
            "audio": {
                "voice": voice_data,
                "format": "mp3"
            },
            "stream": False
        }
        self._do_request(payload, output_path, max_retries)

    def synthesize_design(self, text, output_path, voice_prompt, max_retries=3):
        """音色设计合成。voice_prompt 为描述目标音色的文本。"""
        if os.path.exists(output_path) and os.path.getsize(output_path) > 0:
            return

        payload = {
            "model": "mimo-v2.5-tts-voicedesign",
            "messages": [
                {"role": "user", "content": voice_prompt},
                {"role": "assistant", "content": text}
            ],
            "audio": {
                "format": "mp3"
            },
            "stream": False
        }
        self._do_request(payload, output_path, max_retries)

    def _do_request(self, payload, output_path, max_retries=3):
        headers = {
            "api-key": self.api_key,
            "Content-Type": "application/json",
            "User-Agent": "Calibre-MiMoTTS/1.0"
        }

        data = json.dumps(payload).encode('utf-8')
        req = urllib.request.Request(self.api_url, data=data, headers=headers, method='POST')

        for attempt in range(max_retries):
            try:
                with urllib.request.urlopen(req, timeout=60) as response:
                    if response.status == 200:
                        result = json.loads(response.read().decode('utf-8'))
                        audio_b64 = result['choices'][0]['message']['audio']['data']
                        with open(output_path, 'wb') as f:
                            f.write(base64.b64decode(audio_b64))
                        return
                    else:
                        raise Exception(f"HTTP {response.status}")
            except urllib.error.HTTPError as e:
                error_body = e.read().decode('utf-8', errors='ignore')
                if e.code == 429:
                    time.sleep(2 ** attempt)
                    continue
                raise Exception(f"API Error {e.code}: {error_body}")
            except Exception as e:
                if attempt == max_retries - 1:
                    raise Exception(f"请求失败: {str(e)}")
                time.sleep(1)
